const express = require('express');
const fs = require('fs');
const TemplateEngine = require('./templateengine');

const app = express();
const engine = new TemplateEngine();

app.use(express.static('public'));

function validateData(data){
    if(!data.title) return false;
    if(!Array.isArray(data.sections)) return false;
    if(!Array.isArray(data.asides)) return false;
    if(!data.nav || !Array.isArray(data.nav)) return false;
    if(!data.footer) return false;
    return true;
}

app.get("/", (req, res) => {
    const raw = fs.readFileSync("./public/index.json");
    const data = JSON.parse(raw);

    if(!validateData(data)){
        return res.status(500).send("Invalid JSON Data");
    }

    const template = fs.readFileSync("./public/index.template.html", "utf-8");
    const html = engine.render(template, data);
    res.send(html);
});

app.listen(5000, () => {
    console.log("Server running at http://localhost:5000");
});