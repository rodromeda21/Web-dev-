class TemplateEngine {
    getValue(obj, path) {
        return path.split('.').reduce((res, key) => (res ? res[key] : undefined), obj);
    }

    render(template, data) {
        // Handle loops: {{#array}} ... {{/array}}
        template = template.replace(/{{#(\w+)}}([\s\S]*?){{\/\1}}/g, (match, key, inner) => {
            const arr = data[key];
            if (!Array.isArray(arr)) return "";
            return arr.map(item => this.render(inner, item)).join("");
        });

        // Replace placeholders including nested properties
        return template.replace(/{{(.*?)}}/g, (match, key) => {
            const value = this.getValue(data, key.trim());
            return value !== undefined ? value : "";
        });
    }
}

module.exports = TemplateEngine;