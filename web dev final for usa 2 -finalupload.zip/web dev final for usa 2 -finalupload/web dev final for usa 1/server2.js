// page2server.js
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const TemplateEngine = require("./TemplateEngine");

const app = express();
app.use(cors());

const engine = new TemplateEngine();

app.get("/page2", (req, res) => {
    // Read JSON
    const jsonData = JSON.parse(fs.readFileSync("page2.json", "utf-8"));

    // Read template
    const template = fs.readFileSync("page2.template.html", "utf-8");

    // Render template dynamically from JSON
    const html = engine.render(template, {
        title: "History of Cyberattacks",
        siteTitle: jsonData.siteTitle,
        mainHeading: jsonData.mainHeading,
        attacks: jsonData.flexAttacks,    // first flex section
        attack2: jsonData.attack2,        // second section
        attack3: jsonData.attack3,        // third section
        lastAttack: jsonData.lastAttack,  // last section
        modernAttacks: jsonData.modernAttacks,
        footer: jsonData.footer
    });

    res.send(html);
});

app.listen(3000, () => console.log("Server running on http://localhost:3000/page2"));