function ChangeFontSize(type) {

    let body = document.body;

    let fontSize = window.getComputedStyle(body, null)
        .getPropertyValue("font-size");

    fontSize = parseFloat(fontSize);

    if (type === "increase") {
        body.style.fontSize = (fontSize + 2) + "px";
    } else {
        body.style.fontSize = (fontSize - 2) + "px";
    }
}




async function renderPageFromJSON() {
    try {
        const response = await fetch('index.json'); // fetch the JSON file
        const data = await response.json();

       
        document.title = data.title;

        
        const flexboxContainer = document.querySelector('.flexbox');
        const flexboxNewLineContainer = document.querySelector('.flexbox-new-line');
        const sideBySideContainer = document.querySelector('.side-by-side');

       
        flexboxContainer.innerHTML = '';
        flexboxNewLineContainer.innerHTML = '';
        sideBySideContainer.innerHTML = '';

   
        data.sections.forEach(section => {
            const element = document.createElement(section.type);
            element.className = section.class;
            element.innerHTML = `<p>${section.content}</p>`;

            
            if (section.type === 'main' || section.type === 'section') {
                if (section.class === 'intro' || section.class === 'section1') {
                    flexboxContainer.appendChild(element);
                } else {
                    flexboxNewLineContainer.appendChild(element);
                }
            } else if (section.type === 'aside') {
                sideBySideContainer.appendChild(element);
            }
        });

       
        const footerNav = document.querySelector('.footer-nav');
        footerNav.innerHTML = ''; 
        const footerList = document.createElement('ul');
        footerList.className = 'footer-list';

        data.footer.links.forEach(link => {
            const li = document.createElement('li');
            li.innerHTML = `<a href="${link.url}" target="_blank">${link.text}</a>`;
            footerList.appendChild(li);
        });

        footerNav.appendChild(footerList);

    } catch (error) {
        console.error('Error loading JSON:', error);
    }
}


renderPageFromJSON();