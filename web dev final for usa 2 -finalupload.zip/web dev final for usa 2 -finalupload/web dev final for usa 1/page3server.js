const express = require('express');
const exphbs  = require('express-handlebars');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.static('public'));

// Handlebars setup
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'templates'));

// JSON validation
function validateData(data){
    if(!data.title || !data.mainHeading || !Array.isArray(data.eras)) return false;
    for(let era of data.eras){
        if(!era.title || !Array.isArray(era.paragraphs)) return false;
        for(let p of era.paragraphs){
            if(!p.text) return false;
        }
    }
    return true;
}

// API route
app.get('/api/page3', (req, res) => {
    const raw = fs.readFileSync('./data_page3.json');
    const data = JSON.parse(raw);

    if(!validateData(data)){
        return res.status(500).json({ error: "Invalid data" });
    }

    res.json(data);
});

// Page 3 route
app.get('/page3', (req, res) => {
    const raw = fs.readFileSync('./data_page3.json');
    const data = JSON.parse(raw);
    res.render('temp_engone_page3', data);
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));